@extends('Backend.master')

@section('title')
    Loan Details

@endsection
@section('content')
    <style>
        .m-0{
            text-align: center;


        }
        .xt td{
            width: 50%;
            text-align: center;
        }
        .cs th{
            text-align: center;
        }
        .cs td{
            text-align: center;
        }
    </style>
    <!-- Begin Page Content -->
    <div class="container-fluid">

        <div class="col-lg-12">

            <div class="card shadow mb-4 border-bottom-info">
                <div class="card-header py-3">
                    <h4 class="text-primary" style="text-align: center; ">Add Savings</h4>
                    @if( $message = Session::get('message') )
                        <h6 class="page-header text-success text-md-center" style="text-align: center">{{ $message }}</h6>
                    @endif
                    @if( $message = Session::get('Negmessage') )
                        <h6 class="page-header text-warning text-md-center" style="text-align: center">{{ $message }}</h6>
                    @endif
                </div>
                <div class="card-body row">
                    <div class="col-md-6 border-right">
                         <form method="POST" action="{{ url('/new-savings') }}">
                        @csrf
                        <div class="form-group row">
                            <div style="width: 40%">
                            <label for="savingsInfo" class="col-md-12">{{ __('Select ID') }}<span style="color: red">*</span></label>
                            </div>
                            <div class="col-md-6" >
                                <select class="form-control" id="savingsInfo" name="member_id" required>
                                    <option value="">==Please Choose One==</option>
                                    @foreach($MembersById as $item)
                                        <option value="{{$item->id}}">{{$item->applicant_name}}({{$item->id}})</option>
                                    @endforeach
                                </select>

                            </div>
                        </div>
                        <div class="form-group row">
                            <div style="width: 40%">
                            <label for="amount" class="col-md-12" >{{ __('Amount') }}<span style="color: red">*</span></label>
                            </div>
                            <div class="col-md-6">
                                <input id="amount" type="number" class="form-control{{ $errors->has('amount') ? ' is-invalid' : '' }}" name="amount" value="{{ old('amount') }}" min="0" max="1000000" required autofocus>

                                @if ($errors->has('amount'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('amount') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <div class="form-group row">
                            <div id="loanLevel" style="width: 40%">

                            </div>
                            <div id="loaniv">

                            </div>

                            <div class="col-md-6" id="loanDiv">
                                @if ($errors->has('amount'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('amount') }}</strong>
                                    </span>
                                @endif
                            </div>

                        </div>
                        <div class="form-group row">
                            <div id="loanServiceLevel" style="width: 40%">

                            </div>

                            <div class="col-md-6" id="loanServiceDiv">
                                @if ($errors->has('amount'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('amount') }}</strong>
                                    </span>
                                @endif
                            </div>

                        </div>
                        <div class="form-group row">
                            <div style="width: 40%">
                            <label for="sheetNo" class="col-md-12 col-form-label newLevel" >{{ __('Sheet No') }}<span style="color: red">*</span></label>
                            </div>
                            <div class="col-md-6">
                                <input id="sheetNo" type="number" class="form-control{{ $errors->has('sheet_no') ? ' is-invalid' : '' }}" name="sheet_no" value="{{ old('sheet_no') }}" min="1" max="10000000" required autofocus>

                                @if ($errors->has('sheet_no'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('sheet_no') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <div class="form-group row mb-0">
                            <div class="col-md-4 offset-7">
                                <button type="submit" class="btn btn-primary">
                                    {{ __('Save') }}
                                </button>
                            </div>
                        </div>
                    </form>
                    </div>
                    <div class="col-md-6 row">
                            <div class="col-sm-4 col-md-4" id="applicantPhoto">

                            </div>
                            <div class="col-sm-5 offset-3">
                                <blockquote id="blockquotes">

                                </blockquote>
                                <p id="accountType"> </p>
                                <p id="paymentAmount"> </p>
                                <p id="loanAmount"> </p>
                                <p id="serviceAmount"> </p>
                            </div>
                    </div>
                </div>
            </div>
        </div>

@endsection


