@extends('front.master')

@section('title')
    Contact Us
@endsection

@section('content')
    <div class="contact-page-wrap">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 col-lg-7">
                    <div class="mapouter"><div class="gmap_canvas"><iframe width="100%" height="500" id="gmap_canvas" src="https://maps.google.com/maps?q=newashi%20&t=&z=13&ie=UTF8&iwloc=&output=embed" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe><a href="https://www.crocothemes.net">crocothemes.net</a></div><style>.mapouter{text-align:right;height:500px;width:100%;}.gmap_canvas {overflow:hidden;background:none!important;height:500px;width:100%;}</style></div>
                </div>
                <div class="col-sm-12 col-lg-5">
                    <div class="entry-content">
                        <h2>@lang('contact.head')</h2>

                        <p></p>

                        <ul class="contact-social d-flex flex-wrap align-items-center">
                            <li><a href="#"><i class="fa fa-pinterest-p"></i></a></li>
                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                            <li><a href="#"><i class="fa fa-behance"></i></a></li>
                            <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                        </ul>

                        <ul class="contact-info p-0">
                            <li><i class="fa fa-phone"></i><span>@lang('contact.mobile')</span></li>
                            <li><i class="fa fa-envelope"></i><span>bdpssl@gmail.com</span></li>
                            <li><i class="fa fa-map-marker"></i><span>@lang('contact.address')</span></li>
                        </ul>
                    </div>
                </div><!-- .col -->

            </div><!-- .row -->
        </div><!-- .container -->
    </div>


@endsection
