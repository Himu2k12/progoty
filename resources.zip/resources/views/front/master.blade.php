@include('front.includes.header')


@include('front.includes.navbar')

@yield('content')



@include('front.includes.footer')
@yield('additional_script')
@include('front.includes.footerScript')
