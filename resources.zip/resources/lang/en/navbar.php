<?php

return[
    'home_menu'=>'Home',
    'about_menu'=>'About Us',
    'contact_us'=>'Contact Us',
    'progoty'=>'Progoty ',
    'bangla'=>'Bangla ',
    'english'=>'English ',
    'top_phone'=>'PHONE ',
    'mail'=>'MAIL ',
    'policy'=>'Policy ',
];