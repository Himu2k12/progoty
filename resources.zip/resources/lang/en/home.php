<?php

return[

    'progoty_name'=>'Nageswari Progoty Savings and Loans Co-operative Society Ltd.',
    'progoty_dialogue'=>'Nageswari Progoty Savings and Loans Co-operative Society Ltd.',
    'about_menu'=>'About Us',
    'contact_us'=>'Contact Us',
];