<?php

return[
    'director_name'=>'Md. Hazrat Ali Khandaker',
    'position'=>'Executive Director',

];