<?php

return[
    'home_menu'=>'হোম',
    'about_menu'=>'আমাদের সম্পর্কে',
    'contact_us'=>'যোগাযোগ করুন',
    'progoty'=>'প্রগতি ',
    'bangla'=>'বাংলা',
    'english'=>'ইংরেজি',
    'top_phone'=>'ফোন',
    'mail'=>'মেইল ',
    'policy'=>'কর্মপন্থা ',
];