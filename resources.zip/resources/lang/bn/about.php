<?php
return[
    'director_name'=>'মো হযরত আলী খন্দকার',
    'position'=>'নির্বাহী পরিচালক ',

];